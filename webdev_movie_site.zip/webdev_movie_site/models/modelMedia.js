
const mongoose = require("mongoose");

const schema = new mongoose.Schema({

  title: {
    type:String,
    required:true
  },
  synopsis: {
    type:String,
    required:true
  },
  smallPoster: {
    type:String,
    required:true
  },
  largePoster: {
    type:String,
    required:true
  }, 
  trailerLink: {
    type:String,
    required:true
  }, 
  type: {
    type:String,
    required:true
  }, 
  isFeatured: {
    type:Boolean,
    required:true
  }, 
  genre: {
    type:String,
    required:true
  } 

});


const heroModel = mongoose.model('mediaHeros', schema);//collection name

module.exports = heroModel;
